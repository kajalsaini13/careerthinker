export default function App() {
  return (
    <div
      style={{
        minHeight: '100vh',
        backgroundColor: '#06080f',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <svg
        width="200"
        height="200"
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Tile background */}
        <rect width="200" height="200" rx="40" fill="#0d1120" />

        {/* Vertical stem — career path going up */}
        <line x1="100" y1="148" x2="100" y2="96" stroke="#a3f97a" strokeWidth="7" strokeLinecap="round" />

        {/* Left branch — one path */}
        <line x1="100" y1="96" x2="68" y2="66" stroke="#a3f97a" strokeWidth="7" strokeLinecap="round" />

        {/* Right branch — another path */}
        <line x1="100" y1="96" x2="132" y2="66" stroke="#a3f97a" strokeWidth="7" strokeLinecap="round" />

        {/* Junction node — decision point */}
        <circle cx="100" cy="96" r="7" fill="#a3f97a" />

        {/* Left terminal node */}
        <circle cx="68" cy="66" r="5.5" fill="none" stroke="#a3f97a" strokeWidth="5.5" />

        {/* Right terminal node — filled, the chosen path */}
        <circle cx="132" cy="66" r="5.5" fill="#a3f97a" />

        {/* Base arrow cap — upward momentum */}
        <path
          d="M86 144 L100 156 L114 144"
          stroke="#a3f97a"
          strokeWidth="7"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
          transform="rotate(180, 100, 150)"
        />
      </svg>
    </div>
  )
}
