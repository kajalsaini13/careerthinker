import React, { useState } from 'react';
import { Map, Sparkles, Loader2, CheckCircle2, Clock, BookOpen, Code, ChevronRight, Trophy } from 'lucide-react';
import { SkillRoadmapResult } from '../../types';

export const SkillRoadmaps: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [targetRole, setTargetRole] = useState('Full Stack Web Developer');
  const [timeframe, setTimeframe] = useState('12 Weeks');
  const [level, setLevel] = useState('Beginner to Intermediate');
  const [roadmap, setRoadmap] = useState<SkillRoadmapResult | null>(null);
  const [completedTopics, setCompletedTopics] = useState<Record<string, boolean>>({});

  const presetRoles = [
    'Full Stack Web Developer',
    'AI & Machine Learning Engineer',
    'Data Analyst & BI Specialist',
    'UI/UX Product Designer',
    'DevOps & Cloud Architect',
    'Product Manager'
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/ai/generate-roadmap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: targetRole, timeframe, level })
      });
      const data = await res.json();
      if (data.success && data.milestones) {
        setRoadmap(data);
      }
    } catch (err) {
      console.error('Failed to generate roadmap:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleTopic = (topicKey: string) => {
    setCompletedTopics(prev => ({ ...prev, [topicKey]: !prev[topicKey] }));
  };

  return (
    <div id="skill-roadmaps" className="space-y-8">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-cyan-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl">
        <div className="max-w-2xl space-y-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-bold border border-cyan-400/30">
            <Map className="w-3.5 h-3.5" />
            <span>AI Skill Roadmaps</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Step-by-Step Learning Paths to Master In-Demand Skills
          </h2>
          <p className="text-cyan-100 text-sm leading-relaxed">
            Eliminate confusion with structured, milestone-based learning plans tailored to your target role, available hours, and experience level.
          </p>
        </div>
      </div>

      {/* Role Presets */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
          Select Popular Career Role:
        </label>
        <div className="flex flex-wrap gap-2">
          {presetRoles.map((role) => (
            <button
              key={role}
              type="button"
              onClick={() => setTargetRole(role)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                targetRole === role
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
              }`}
            >
              {role}
            </button>
          ))}
        </div>
      </div>

      {/* Form Controls */}
      <form onSubmit={handleGenerate} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Target Role Name
            </label>
            <input
              type="text"
              required
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Target Timeframe
            </label>
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 bg-white"
            >
              <option value="6 Weeks">6 Weeks (Accelerated)</option>
              <option value="12 Weeks">12 Weeks (Standard)</option>
              <option value="16 Weeks">16 Weeks (Comprehensive)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Experience Level
            </label>
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 bg-white"
            >
              <option value="Absolute Beginner">Absolute Beginner</option>
              <option value="Beginner to Intermediate">Beginner to Intermediate</option>
              <option value="Advanced Practitioner">Advanced Practitioner</option>
            </select>
          </div>

        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-base hover:from-blue-700 hover:to-indigo-700 transition-all shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Building Custom Skill Roadmap with Gemini AI...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 text-blue-200" />
              <span>Generate Step-by-Step Skill Roadmap</span>
            </>
          )}
        </button>
      </form>

      {/* Roadmap Output */}
      {roadmap && (
        <div id="roadmap-output" className="space-y-8 animate-in fade-in duration-300">
          
          <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-blue-400 uppercase tracking-widest">
                AI Generated Skill Path
              </span>
              <h3 className="text-2xl sm:text-3xl font-extrabold">{roadmap.title}</h3>
            </div>
            <div className="flex items-center gap-2 bg-blue-500/20 px-4 py-2 rounded-2xl border border-blue-400/30 text-blue-300 text-xs font-bold">
              <Clock className="w-4 h-4" />
              <span>{roadmap.timeframe} Duration</span>
            </div>
          </div>

          {/* Timeline Milestones */}
          <div className="space-y-6">
            {roadmap.milestones.map((m, idx) => (
              <div
                key={idx}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md space-y-5 relative"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-3">
                    <span className="w-9 h-9 rounded-xl bg-blue-600 text-white font-black text-sm flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <div>
                      <h4 className="text-xl font-bold text-slate-900">{m.phase}</h4>
                      <p className="text-xs font-semibold text-blue-600">{m.duration}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Core Topics Checklist */}
                  <div className="space-y-2">
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                      <span>Topics to Master</span>
                    </h5>
                    <div className="space-y-1.5">
                      {m.topics.map((t, tIdx) => {
                        const key = `m${idx}_t${tIdx}`;
                        const isDone = !!completedTopics[key];
                        return (
                          <div
                            key={tIdx}
                            onClick={() => toggleTopic(key)}
                            className={`p-2.5 rounded-xl border text-xs font-medium cursor-pointer transition-colors flex items-center gap-2 ${
                              isDone
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-800 line-through'
                                : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-blue-300'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isDone}
                              onChange={() => {}}
                              className="w-3.5 h-3.5 rounded text-blue-600 shrink-0"
                            />
                            <span>{t}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Hands-on Projects */}
                  <div className="space-y-2">
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Code className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Portfolio Projects</span>
                    </h5>
                    <div className="space-y-2">
                      {m.projects.map((p, pIdx) => (
                        <div key={pIdx} className="p-3 rounded-xl bg-indigo-50/60 border border-indigo-100 text-xs text-indigo-950 font-semibold">
                          🚀 {p}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recommended Resources */}
                  <div className="space-y-2">
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <Trophy className="w-3.5 h-3.5 text-amber-600" />
                      <span>Curated Resources</span>
                    </h5>
                    <ul className="space-y-1.5 text-xs text-slate-600">
                      {m.recommendedResources.map((r, rIdx) => (
                        <li key={rIdx} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200/60">
                          <ChevronRight className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          <span>{r}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>

              </div>
            ))}
          </div>

        </div>
      )}

    </div>
  );
};
