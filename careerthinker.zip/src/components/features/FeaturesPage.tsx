import React, { useState, useEffect } from 'react';
import { Compass, FileText, Map, Video, Sparkles } from 'lucide-react';
import { FeatureTab } from '../../types';
import { AICareerGuidance } from './AICareerGuidance';
import { ResumeBuilder } from './ResumeBuilder';
import { SkillRoadmaps } from './SkillRoadmaps';
import { InterviewPrep } from './InterviewPrep';

interface FeaturesPageProps {
  initialFeature?: FeatureTab;
}

export const FeaturesPage: React.FC<FeaturesPageProps> = ({ initialFeature = 'guidance' }) => {
  const [activeFeature, setActiveFeature] = useState<FeatureTab>(initialFeature);

  useEffect(() => {
    if (initialFeature) {
      setActiveFeature(initialFeature);
    }
  }, [initialFeature]);

  const featureTabs = [
    { id: 'guidance' as const, label: 'AI Career Guidance', icon: Compass },
    { id: 'resume' as const, label: 'Resume Builder', icon: FileText },
    { id: 'roadmaps' as const, label: 'Skill Roadmaps', icon: Map },
    { id: 'interview' as const, label: 'Interview Preparation', icon: Video },
  ];

  return (
    <div id="features-page" className="py-10 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-wider border border-blue-200">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>AI Career Suite</span>
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
            Interactive AI Career Tools
          </h1>
          <p className="text-slate-600 text-base leading-relaxed">
            Switch between our specialized career modules to explore options, optimize resumes, generate roadmaps, and practice interviews.
          </p>
        </div>

        {/* Feature Sub-Navigation Bar */}
        <div className="flex items-center justify-center">
          <div className="inline-flex p-1.5 bg-white rounded-2xl border border-slate-200 shadow-sm max-w-full overflow-x-auto gap-1">
            {featureTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeFeature === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`feature-tab-${tab.id}`}
                  onClick={() => setActiveFeature(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                      : 'text-slate-600 hover:text-blue-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Feature Tab View Rendering */}
        <div className="pt-2">
          {activeFeature === 'guidance' && <AICareerGuidance />}
          {activeFeature === 'resume' && <ResumeBuilder />}
          {activeFeature === 'roadmaps' && <SkillRoadmaps />}
          {activeFeature === 'interview' && <InterviewPrep />}
        </div>

      </div>
    </div>
  );
};
