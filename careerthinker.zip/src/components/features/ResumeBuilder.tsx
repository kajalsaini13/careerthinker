import React, { useState } from 'react';
import { FileText, Sparkles, Loader2, CheckCircle2, AlertTriangle, Copy, Download, RefreshCw, Award, Plus, Trash2 } from 'lucide-react';
import { ResumeReviewResult } from '../../types';

export const ResumeBuilder: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [targetRole, setTargetRole] = useState('Full Stack Software Engineer');
  const [fullName, setFullName] = useState('Aarav Mehta');
  const [email, setEmail] = useState('aarav.mehta@university.edu');
  const [phone, setPhone] = useState('+91 98765 43210');
  const [summary, setSummary] = useState('Passionate 4th-year Computer Science undergraduate with hands-on experience in React, TypeScript, Node.js, and cloud deployments. Built 3 full-stack applications with 5k+ monthly active users.');
  
  const [experience, setExperience] = useState([
    {
      company: 'TechCorp Solutions',
      role: 'Frontend Developer Intern',
      period: 'May 2025 - Aug 2025',
      bullets: 'Developed responsive React components for customer analytics dashboard. Fixed 25+ frontend bug tickets and improved page load speeds.'
    }
  ]);

  const [projects, setProjects] = useState([
    {
      title: 'Smart Learning Platform',
      tech: 'React, Node.js, PostgreSQL, Gemini API',
      description: 'Architected an online course manager with real-time AI quiz generation. Deployed on Google Cloud Run.'
    }
  ]);

  const [skillsText, setSkillsText] = useState('TypeScript, JavaScript, React, Node.js, Express, Python, SQL, Git, Tailwind CSS, REST APIs');

  const [reviewResult, setReviewResult] = useState<ResumeReviewResult | null>(null);
  const [copied, setCopied] = useState(false);

  // Compile full text resume
  const generateFullText = () => {
    return `${fullName.toUpperCase()}
Email: ${email} | Phone: ${phone} | Target Role: ${targetRole}

SUMMARY
${summary}

SKILLS
${skillsText}

EXPERIENCE
${experience.map(e => `${e.role} @ ${e.company} (${e.period})\n- ${e.bullets}`).join('\n\n')}

PROJECTS
${projects.map(p => `${p.title} [Tech: ${p.tech}]\n- ${p.description}`).join('\n\n')}`;
  };

  const handleAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setReviewResult(null);

    const fullResumeText = generateFullText();

    try {
      const res = await fetch('/api/ai/resume-review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText: fullResumeText, targetRole })
      });
      const data = await res.json();
      if (data.success) {
        setReviewResult(data);
      }
    } catch (err) {
      console.error('Failed to review resume:', err);
    } fontfinally: {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generateFullText());
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const downloadTxt = () => {
    const element = document.createElement("a");
    const file = new Blob([generateFullText()], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${fullName.replace(/\s+/g, '_')}_Resume.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div id="resume-builder" className="space-y-8">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-blue-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl">
        <div className="max-w-2xl space-y-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-400/30">
            <FileText className="w-3.5 h-3.5" />
            <span>ATS Resume Builder & AI Auditor</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Build & Audit Your Resume for 90+ ATS Score
          </h2>
          <p className="text-indigo-100 text-sm leading-relaxed">
            Fill out your details below or let AI audit your bullet points, identify missing keywords, and transform generic descriptions into high-impact metrics.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Resume Form Editor */}
        <div className="lg:col-span-7 space-y-6 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h3 className="text-xl font-bold text-slate-900">Resume Editor</h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={copyToClipboard}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copied ? 'Copied!' : 'Copy Text'}</span>
              </button>
              <button
                type="button"
                onClick={downloadTxt}
                className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 text-xs font-semibold hover:bg-blue-100 flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export TXT</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleAudit} className="space-y-5">
            
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Target Role
              </label>
              <input
                type="text"
                required
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 font-semibold"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">Phone</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Professional Summary
              </label>
              <textarea
                rows={3}
                required
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Technical & Core Skills (Comma Separated)
              </label>
              <textarea
                rows={2}
                required
                value={skillsText}
                onChange={(e) => setSkillsText(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Work Experience */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Work / Internship Experience
                </label>
                <button
                  type="button"
                  onClick={() => setExperience([...experience, { company: '', role: '', period: '', bullets: '' }])}
                  className="text-xs font-semibold text-blue-600 hover:underline flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Experience
                </button>
              </div>

              {experience.map((exp, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 relative">
                  {experience.length > 1 && (
                    <button
                      type="button"
                      onClick={() => setExperience(experience.filter((_, i) => i !== idx))}
                      className="absolute top-3 right-3 text-slate-400 hover:text-red-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <input
                      type="text"
                      placeholder="Company"
                      value={exp.company}
                      onChange={(e) => {
                        const updated = [...experience];
                        updated[idx].company = e.target.value;
                        setExperience(updated);
                      }}
                      className="px-3 py-2 rounded-lg bg-white border border-slate-200 text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Role Title"
                      value={exp.role}
                      onChange={(e) => {
                        const updated = [...experience];
                        updated[idx].role = e.target.value;
                        setExperience(updated);
                      }}
                      className="px-3 py-2 rounded-lg bg-white border border-slate-200 text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Period e.g. Summer 2025"
                      value={exp.period}
                      onChange={(e) => {
                        const updated = [...experience];
                        updated[idx].period = e.target.value;
                        setExperience(updated);
                      }}
                      className="px-3 py-2 rounded-lg bg-white border border-slate-200 text-xs"
                    />
                  </div>
                  <textarea
                    rows={2}
                    placeholder="Key responsibilities & accomplishments..."
                    value={exp.bullets}
                    onChange={(e) => {
                      const updated = [...experience];
                      updated[idx].bullets = e.target.value;
                      setExperience(updated);
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-white border border-slate-200 text-xs"
                  />
                </div>
              ))}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-base hover:from-blue-700 hover:to-indigo-700 transition-all shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Auditing Resume with Gemini AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 text-blue-200" />
                  <span>Audit & Optimize Resume with AI</span>
                </>
              )}
            </button>

          </form>
        </div>

        {/* Right Column: AI Audit Results */}
        <div className="lg:col-span-5 space-y-6">
          {reviewResult ? (
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-blue-100 shadow-xl space-y-6 animate-in fade-in duration-300">
              
              {/* Score gauge */}
              <div className="bg-slate-900 rounded-2xl p-6 text-white text-center space-y-3">
                <p className="text-xs font-bold text-blue-400 uppercase tracking-widest">Calculated ATS Compatibility</p>
                <div className="text-5xl font-black text-white">
                  {reviewResult.score}<span className="text-2xl text-blue-400">/100</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed max-w-xs mx-auto">
                  {reviewResult.summary}
                </p>
              </div>

              {/* Key Strengths */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Key Strengths</span>
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {reviewResult.strengths.map((str, i) => (
                    <li key={i} className="flex items-start gap-2 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0 mt-1.5"></span>
                      <span>{str}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Areas to Improve */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>ATS Improvement Opportunities</span>
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  {reviewResult.improvements.map((imp, i) => (
                    <li key={i} className="flex items-start gap-2 bg-amber-50/60 p-2.5 rounded-xl border border-amber-100">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-600 shrink-0 mt-1.5"></span>
                      <span>{imp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Recommended ATS Keywords */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Recommended Industry Keywords
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {reviewResult.atsKeywords.map((kw, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-md bg-blue-50 text-blue-800 text-xs font-semibold border border-blue-100">
                      + {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* AI Bullet Point Rewrites */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                  AI High-Impact Bullet Rewrites
                </h4>
                <div className="space-y-3">
                  {reviewResult.bulletSuggestions.map((sug, i) => (
                    <div key={i} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                      <p className="text-slate-400 line-through">"{sug.original}"</p>
                      <p className="text-blue-900 font-semibold bg-blue-50 p-2 rounded-lg border border-blue-100">
                        ✨ "{sug.improved}"
                      </p>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-8 text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-bold text-slate-800">No AI Audit Run Yet</h4>
              <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                Fill in your experience details on the left and click "Audit & Optimize Resume with AI" to receive a real-time ATS compatibility score and bullet point optimizations.
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
