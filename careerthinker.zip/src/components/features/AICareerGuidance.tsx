import React, { useState } from 'react';
import { Compass, Sparkles, Loader2, CheckCircle2, TrendingUp, DollarSign, Briefcase, Award, ArrowRight, RefreshCw } from 'lucide-react';
import { CareerRecommendation } from '../../types';

export const AICareerGuidance: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [interests, setInterests] = useState('Artificial Intelligence, Software Engineering, Problem Solving');
  const [skills, setSkills] = useState('Python basics, React/TypeScript, Data structures, Logic');
  const [education, setEducation] = useState('B.Tech Computer Science (3rd Year)');
  const [workStyle, setWorkStyle] = useState('Hybrid & Collaborative');
  const [goals, setGoals] = useState('Build scalable products and earn high compensation in top tech company');
  const [recommendations, setRecommendations] = useState<CareerRecommendation[] | null>(null);

  const samplePresets = [
    {
      label: '🚀 Tech & AI Engineer',
      interests: 'Machine Learning, Full Stack Web Dev, Cloud Architecture',
      skills: 'Python, TypeScript, React, SQL',
      education: 'Undergraduate Computer Science',
      workStyle: 'Fast-paced, Remote friendly',
      goals: 'High growth software engineering career'
    },
    {
      label: '📊 Data Analyst & Business',
      interests: 'Data Analytics, Market Research, Product Strategy',
      skills: 'SQL, Excel, Python, Tableau, Presentation',
      education: 'BBA / Economics / B.Tech',
      workStyle: 'Data-driven, Cross-functional',
      goals: 'Lead product & business intelligence decisions'
    },
    {
      label: '🎨 UI/UX Product Designer',
      interests: 'Design systems, User psychology, Digital prototyping',
      skills: 'Figma, Wireframing, User Research, HTML/CSS',
      education: 'Design / Arts / Engineering',
      workStyle: 'Creative, Collaborative',
      goals: 'Design intuitive products used by millions'
    }
  ];

  const handleApplyPreset = (preset: typeof samplePresets[0]) => {
    setInterests(preset.interests);
    setSkills(preset.skills);
    setEducation(preset.education);
    setWorkStyle(preset.workStyle);
    setGoals(preset.goals);
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setRecommendations(null);

    try {
      const res = await fetch('/api/ai/career-guidance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ interests, skills, education, workStyle, goals })
      });
      const data = await res.json();
      if (data.success && data.recommendations) {
        setRecommendations(data.recommendations);
      }
    } catch (err) {
      console.error('Failed to fetch guidance:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="ai-career-guidance" className="space-y-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden shadow-xl">
        <div className="max-w-2xl relative z-10 space-y-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-400/30">
            <Compass className="w-3.5 h-3.5" />
            <span>AI Career Pathfinder</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Discover Your High-Match Career Path
          </h2>
          <p className="text-blue-100 text-sm leading-relaxed">
            Tell us about your background, current skill set, and interests. Gemini AI will analyze your profile to match you with future-proof career choices.
          </p>
        </div>
      </div>

      {/* Preset Quick Buttons */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
          Quick Fill Sample Profiles:
        </label>
        <div className="flex flex-wrap gap-2">
          {samplePresets.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <form onSubmit={handleGenerate} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Academic Degree / Education Stage
            </label>
            <input
              type="text"
              required
              value={education}
              onChange={(e) => setEducation(e.target.value)}
              placeholder="e.g. Computer Science, 3rd Year"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Preferred Work Culture
            </label>
            <input
              type="text"
              required
              value={workStyle}
              onChange={(e) => setWorkStyle(e.target.value)}
              placeholder="e.g. Remote, Collaborative, Fast-paced"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Your Current Technical & Soft Skills
            </label>
            <textarea
              rows={2}
              required
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              placeholder="e.g. Python, React, Data analysis, Public speaking, Logic"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Interests & Passion Areas
            </label>
            <textarea
              rows={2}
              required
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="e.g. Artificial intelligence, finance apps, design, solving complex math problems"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Long-term Career Goals & Aspirations
            </label>
            <input
              type="text"
              required
              value={goals}
              onChange={(e) => setGoals(e.target.value)}
              placeholder="e.g. Lead an engineering team, earn $120k+, work in AI"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-base hover:from-blue-700 hover:to-indigo-700 transition-all shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Analyzing Profile with Gemini AI...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 text-blue-200" />
              <span>Generate AI Career Recommendations</span>
            </>
          )}
        </button>
      </form>

      {/* Results Section */}
      {recommendations && (
        <div id="guidance-results" className="space-y-6 animate-in fade-in duration-300">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-6 h-6 text-blue-600" />
              <span>Your Top 3 Recommended Career Paths</span>
            </h3>
            <button
              onClick={() => setRecommendations(null)}
              className="text-xs font-semibold text-slate-500 hover:text-blue-600 flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Results</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {recommendations.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-100 shadow-lg shadow-blue-900/5 space-y-6 relative overflow-hidden"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                      Option #{index + 1}
                    </span>
                    <h4 className="text-2xl font-extrabold text-slate-900">{item.title}</h4>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="px-4 py-2 rounded-2xl bg-blue-50 text-blue-700 border border-blue-200 font-bold text-sm flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                      <span>{item.matchPercentage}% AI Match</span>
                    </div>
                  </div>
                </div>

                <p className="text-slate-700 text-sm leading-relaxed">
                  {item.description}
                </p>

                {/* Key Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <DollarSign className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-semibold uppercase">Estimated Salary</p>
                      <p className="text-sm font-bold text-slate-900">{item.salaryRange}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                      <Briefcase className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-semibold uppercase">Industry Demand</p>
                      <p className="text-sm font-bold text-slate-900">{item.demand}</p>
                    </div>
                  </div>
                </div>

                {/* Day in life & skills */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      Key Technical Skills Needed
                    </h5>
                    <div className="flex flex-wrap gap-1.5">
                      {item.keySkillsNeeded.map((skill, sIdx) => (
                        <span key={sIdx} className="px-3 py-1 rounded-lg bg-blue-50 text-blue-800 text-xs font-semibold border border-blue-100">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                      Day-in-the-Life Overview
                    </h5>
                    <p className="text-xs text-slate-600 leading-relaxed bg-white p-3 rounded-xl border border-slate-200">
                      {item.dayInLife}
                    </p>
                  </div>
                </div>

                {/* Actionable Next Steps */}
                <div className="border-t border-slate-100 pt-5">
                  <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                    Recommended Action Steps
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {item.nextSteps.map((step, stIdx) => (
                      <div key={stIdx} className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                        <span>{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
