import React, { useState } from 'react';
import { Video, Sparkles, Loader2, CheckCircle2, AlertCircle, Award, MessageSquare, Play, RefreshCw, Send } from 'lucide-react';
import { InterviewFeedbackResult } from '../../types';

export const InterviewPrep: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [targetRole, setTargetRole] = useState('Software Engineer');
  const [category, setCategory] = useState<'behavioral' | 'technical' | 'situational'>('behavioral');
  
  const sampleQuestions = {
    behavioral: [
      "Tell me about a time when you faced a difficult technical bug under tight deadlines. How did you handle it?",
      "Describe a situation where you had a disagreement with a team member on project architecture. How was it resolved?",
      "Why do you want to join our company, and what unique value will you bring in your first 90 days?"
    ],
    technical: [
      "How would you optimize a slow database query in Express/Node.js with millions of rows?",
      "Explain the difference between SQL vs NoSQL databases and when you would choose Firestore vs PostgreSQL.",
      "How does asynchronous event loop execution work in JavaScript?"
    ],
    situational: [
      "If production goes down during a major feature release, what are your immediate triage steps?",
      "How do you prioritize trade-offs between shipping a feature fast versus refactoring clean code?",
      "Explain how you would design a URL shortener system like Bitly."
    ]
  };

  const [questionIndex, setQuestionIndex] = useState(0);
  const currentQuestion = sampleQuestions[category][questionIndex];
  const [userResponse, setUserResponse] = useState('');
  const [feedback, setFeedback] = useState<InterviewFeedbackResult | null>(null);

  const handleEvaluate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userResponse.trim()) return;

    setLoading(true);
    setFeedback(null);

    try {
      const res = await fetch('/api/ai/interview-feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentQuestion,
          userResponse,
          targetRole
        })
      });
      const data = await res.json();
      if (data.success) {
        setFeedback(data);
      }
    } catch (err) {
      console.error('Failed to get interview feedback:', err);
    } finally {
      setLoading(false);
    }
  };

  const nextQuestion = () => {
    setQuestionIndex((prev) => (prev + 1) % sampleQuestions[category].length);
    setUserResponse('');
    setFeedback(null);
  };

  const loadSampleAnswer = () => {
    setUserResponse(`In my previous internship project, our team encountered a critical latency issue 2 days before launch. I conducted profiling, identified an unindexed database join, and added missing indexes while refactoring the React query handler. This reduced load times by 45% and ensured an on-time release.`);
  };

  return (
    <div id="interview-prep" className="space-y-8">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-sky-900 via-blue-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl">
        <div className="max-w-2xl space-y-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-bold border border-sky-400/30">
            <Video className="w-3.5 h-3.5" />
            <span>AI Mock Interview Simulator</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Practice Real Interview Questions & Ace Every Round
          </h2>
          <p className="text-sky-100 text-sm leading-relaxed">
            Test your answers against Gemini AI. Receive instant feedback based on the STAR framework, score evaluations, and model responses.
          </p>
        </div>
      </div>

      {/* Role & Category Controls */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Target Interview Role
            </label>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Question Category
            </label>
            <div className="flex gap-2">
              {(['behavioral', 'technical', 'situational'] as const).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => {
                    setCategory(cat);
                    setQuestionIndex(0);
                    setUserResponse('');
                    setFeedback(null);
                  }}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold capitalize transition-all ${
                    category === cat
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Question Box */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-100 shadow-lg shadow-blue-900/5 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <span className="text-xs font-extrabold text-blue-600 uppercase tracking-wider">
            Question #{questionIndex + 1} of {sampleQuestions[category].length} ({category})
          </span>
          <button
            onClick={nextQuestion}
            className="text-xs font-bold text-slate-600 hover:text-blue-600 flex items-center gap-1 bg-slate-100 px-3 py-1.5 rounded-lg"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Next Question</span>
          </button>
        </div>

        <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-100 flex items-start gap-3">
          <MessageSquare className="w-6 h-6 text-blue-600 shrink-0 mt-0.5" />
          <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
            "{currentQuestion}"
          </h3>
        </div>

        <form onSubmit={handleEvaluate} className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Your Answer / Response
            </label>
            <button
              type="button"
              onClick={loadSampleAnswer}
              className="text-xs font-semibold text-blue-600 hover:underline"
            >
              Fill Sample Response
            </button>
          </div>

          <textarea
            rows={5}
            required
            value={userResponse}
            onChange={(e) => setUserResponse(e.target.value)}
            placeholder="Type your response here using the STAR framework (Situation, Task, Action, Result)..."
            className="w-full p-4 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:border-blue-500 leading-relaxed"
          />

          <button
            type="submit"
            disabled={loading || !userResponse.trim()}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-base hover:from-blue-700 hover:to-indigo-700 transition-all shadow-md shadow-blue-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Evaluating Response with Gemini AI...</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5 text-blue-200" />
                <span>Evaluate Response & Get AI Feedback</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* AI Feedback Output */}
      {feedback && (
        <div id="interview-feedback-output" className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-200 shadow-xl space-y-6 animate-in fade-in duration-300">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
            <div>
              <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                Interview Performance Review
              </span>
              <h4 className="text-2xl font-extrabold text-slate-900">Evaluation Analysis</h4>
            </div>
            <div className="px-5 py-2.5 rounded-2xl bg-slate-900 text-white font-extrabold text-lg flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>Score: {feedback.score} / 100</span>
            </div>
          </div>

          <p className="text-slate-700 text-sm leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-200 font-medium">
            {feedback.feedback}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Key Answer Strengths</span>
              </h5>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {feedback.keyStrengths.map((s, i) => (
                  <li key={i} className="flex items-start gap-2 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0 mt-1.5"></span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Aspects to Include / Improve</span>
              </h5>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {feedback.missingAspects.map((m, i) => (
                  <li key={i} className="flex items-start gap-2 bg-amber-50/70 p-2.5 rounded-xl border border-amber-100">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-600 shrink-0 mt-1.5"></span>
                    <span>{m}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-5">
            <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Sample High-Impact Model Answer
            </h5>
            <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-100 text-xs text-blue-950 leading-relaxed font-medium">
              ✨ "{feedback.sampleIdealResponse}"
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
