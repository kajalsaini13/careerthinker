import React from 'react';
import { Compass, Target, Award, Users, Heart, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import { TEAM_MEMBERS } from '../../data/mockData';
import { PageTab } from '../../types';

interface AboutPageProps {
  setActiveTab: (tab: PageTab) => void;
  onOpenConsultation: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ setActiveTab, onOpenConsultation }) => {
  return (
    <div id="about-page" className="py-12 sm:py-20 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        
        {/* Header Hero */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="inline-block px-3.5 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-wider border border-blue-200">
            About CareerThinker
          </span>
          <h1 className="text-4xl sm:text-6xl font-extrabold text-slate-900 tracking-tight">
            Democratizing Career Clarity for Every Student
          </h1>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            We believe no student should feel lost or overwhelmed when transitioning from education to a fulfilling career.
          </p>
        </div>

        {/* Mission & Vision Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          <div className="bg-white rounded-3xl p-8 border border-blue-100 shadow-lg shadow-blue-900/5 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900">Our Mission</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              To empower students with personalized, data-backed career intelligence. By combining state-of-the-art AI with proven industry frameworks, we turn career confusion into clear, executable steps.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 border border-blue-100 shadow-lg shadow-blue-900/5 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center">
              <Compass className="w-6 h-6" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900">Our Vision</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              A world where every student—regardless of location or family background—has access to elite career mentorship, customized skill roadmaps, and instant interview preparation.
            </p>
          </div>

        </div>

        {/* Our Impact Grid */}
        <div className="bg-gradient-to-r from-blue-900 via-slate-900 to-indigo-900 rounded-3xl p-8 sm:p-12 text-white space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-extrabold">Our Global Student Impact</h2>
            <p className="text-blue-200 text-sm">
              Real results delivered through intelligent guidance across top universities.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="text-3xl sm:text-4xl font-black text-blue-400">100K+</div>
              <p className="text-xs text-slate-300 mt-1 font-semibold">Active Students</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="text-3xl sm:text-4xl font-black text-emerald-400">95%</div>
              <p className="text-xs text-slate-300 mt-1 font-semibold">Job Offer Placement</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="text-3xl sm:text-4xl font-black text-amber-400">500+</div>
              <p className="text-xs text-slate-300 mt-1 font-semibold">Skill Roadmaps</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="text-3xl sm:text-4xl font-black text-blue-300">4.9/5</div>
              <p className="text-xs text-slate-300 mt-1 font-semibold">Average Rating</p>
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="space-y-8">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl font-extrabold text-slate-900">Core Values That Drive Us</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="bg-white rounded-2xl p-6 border border-slate-200 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">01</div>
              <h4 className="text-lg font-bold text-slate-900">Student First</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Every feature we build prioritizes student clarity, affordability, and genuine career growth over fluff.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">02</div>
              <h4 className="text-lg font-bold text-slate-900">AI Precision</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Leveraging Google Gemini models to deliver real-time, highly tailored career insights and ATS recommendations.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">03</div>
              <h4 className="text-lg font-bold text-slate-900">Continuous Growth</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Career preparation isn't a one-time event; we support students with evolving roadmaps as industry trends shift.
              </p>
            </div>

          </div>
        </div>

        {/* Founder & Team Section */}
        <div className="space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="text-3xl font-extrabold text-slate-900">Meet Our Team</h2>
            <p className="text-slate-600 text-sm">
              Founders and educators combining AI engineering with deep hiring experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TEAM_MEMBERS.map((member, i) => (
              <div key={i} className="bg-white rounded-3xl p-6 border border-slate-200 text-center space-y-4 hover:shadow-lg transition-shadow">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-24 h-24 rounded-full object-cover mx-auto border-4 border-blue-100"
                />
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{member.name}</h3>
                  <p className="text-xs font-semibold text-blue-600 mt-0.5">{member.role}</p>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="bg-blue-600 rounded-3xl p-8 sm:p-12 text-white text-center space-y-6 shadow-xl shadow-blue-500/20">
          <h2 className="text-3xl sm:text-4xl font-extrabold">Ready to Discover Your Ideal Career Path?</h2>
          <p className="text-blue-100 text-base max-w-2xl mx-auto">
            Take the first step today. Explore our interactive AI Career Guidance or schedule a free 1-on-1 consultation session.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => setActiveTab('features')}
              className="px-8 py-3.5 rounded-xl bg-white text-blue-700 font-bold hover:bg-blue-50 transition-colors"
            >
              Explore AI Features
            </button>
            <button
              onClick={onOpenConsultation}
              className="px-8 py-3.5 rounded-xl bg-blue-800 text-white font-bold hover:bg-blue-900 transition-colors border border-blue-400/30"
            >
              Book Consultation
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
