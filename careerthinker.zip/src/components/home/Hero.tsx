import React from 'react';
import { Sparkles, ArrowRight, CheckCircle2, TrendingUp, Award, Users, Bot, Compass, FileText, Map, Video } from 'lucide-react';
import { PageTab } from '../../types';

interface HeroProps {
  setActiveTab: (tab: PageTab) => void;
  onOpenConsultation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ setActiveTab, onOpenConsultation }) => {
  return (
    <section id="hero-section" className="relative pt-12 pb-20 md:pt-20 md:pb-32 bg-gradient-to-b from-blue-50/70 via-white to-slate-50 overflow-hidden">
      
      {/* Subtle Background Glow Elements */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-blue-400/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-10 right-10 w-72 h-72 bg-indigo-300/10 rounded-full blur-2xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Tagline Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-blue-800 text-xs sm:text-sm font-semibold shadow-xs">
            <Sparkles className="w-4 h-4 text-blue-600 animate-spin" style={{ animationDuration: '4s' }} />
            <span>Next-Gen Career Platform for Students & Graduates</span>
          </div>
        </div>

        {/* Main Headline */}
        <div className="text-center max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
            Shape Your Future with <br className="hidden sm:inline" />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-800">
              AI Career Intelligence
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed max-w-2xl mx-auto">
            Choose the right career path, master high-demand skills with step-by-step roadmaps, craft ATS-proof resumes, and ace interviews with live AI coaching.
          </p>

          {/* Call to Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              id="hero-get-started-btn"
              onClick={() => setActiveTab('features')}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 text-white font-bold text-base shadow-xl shadow-blue-500/25 hover:shadow-2xl hover:shadow-blue-500/35 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-3 group"
            >
              <span>Get Started Free</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              id="hero-consultation-btn"
              onClick={onOpenConsultation}
              className="w-full sm:w-auto px-7 py-4 rounded-2xl bg-white border border-slate-200 text-slate-800 font-semibold text-base hover:bg-slate-50 hover:border-blue-300 transition-all flex items-center justify-center gap-2 shadow-xs"
            >
              <span>Book 1-on-1 Guidance</span>
            </button>
          </div>

          {/* Quick Features Micro-Badges */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs sm:text-sm font-medium text-slate-600">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-600" /> AI Career Pathfinder
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-600" /> ATS Resume Auditor
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-600" /> Custom Skill Roadmaps
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-600" /> AI Mock Interviews
            </span>
          </div>
        </div>

        {/* Hero Interactive Card Mockup */}
        <div className="mt-12 lg:mt-16 max-w-5xl mx-auto">
          <div className="bg-white rounded-3xl p-4 sm:p-8 border border-blue-100 shadow-2xl shadow-blue-900/10 relative overflow-hidden">
            
            {/* Top Mock Window Header */}
            <div className="flex items-center justify-between pb-6 border-b border-slate-100 mb-6">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-400"></span>
                <span className="w-3 h-3 rounded-full bg-amber-400"></span>
                <span className="w-3 h-3 rounded-full bg-emerald-400"></span>
                <span className="ml-2 text-xs font-mono text-slate-400">careerthinker.ai/workspace</span>
              </div>
              <div className="flex items-center gap-2 bg-blue-50 text-blue-700 text-xs font-semibold px-3 py-1 rounded-full border border-blue-100">
                <Bot className="w-3.5 h-3.5" />
                <span>AI Career Agent Active</span>
              </div>
            </div>

            {/* Grid of Interactive Preview Features */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              
              {/* Feature Box 1 */}
              <div 
                onClick={() => setActiveTab('features')}
                className="p-4 rounded-2xl bg-gradient-to-b from-slate-50 to-blue-50/50 border border-slate-200/80 hover:border-blue-400 transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center mb-3 shadow-md shadow-blue-500/20 group-hover:scale-110 transition-transform">
                  <Compass className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">AI Guidance</h4>
                <p className="text-xs text-slate-500 mt-1">Discover high-fit career paths with salary projections.</p>
                <div className="mt-3 text-[11px] font-bold text-blue-600 flex items-center gap-1">
                  <span>96% Match Score</span>
                  <TrendingUp className="w-3 h-3" />
                </div>
              </div>

              {/* Feature Box 2 */}
              <div 
                onClick={() => setActiveTab('features')}
                className="p-4 rounded-2xl bg-gradient-to-b from-slate-50 to-blue-50/50 border border-slate-200/80 hover:border-blue-400 transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-3 shadow-md shadow-indigo-500/20 group-hover:scale-110 transition-transform">
                  <FileText className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">Resume Builder</h4>
                <p className="text-xs text-slate-500 mt-1">Build ATS-optimized resumes with AI bullet rewriters.</p>
                <div className="mt-3 text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                  <span>92/100 ATS Score</span>
                  <CheckCircle2 className="w-3 h-3" />
                </div>
              </div>

              {/* Feature Box 3 */}
              <div 
                onClick={() => setActiveTab('features')}
                className="p-4 rounded-2xl bg-gradient-to-b from-slate-50 to-blue-50/50 border border-slate-200/80 hover:border-blue-400 transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-500 text-white flex items-center justify-center mb-3 shadow-md shadow-blue-400/20 group-hover:scale-110 transition-transform">
                  <Map className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">Skill Roadmaps</h4>
                <p className="text-xs text-slate-500 mt-1">Structured week-by-week learning paths & capstones.</p>
                <div className="mt-3 text-[11px] font-bold text-blue-600 flex items-center gap-1">
                  <span>12-Week Roadmap</span>
                </div>
              </div>

              {/* Feature Box 4 */}
              <div 
                onClick={() => setActiveTab('features')}
                className="p-4 rounded-2xl bg-gradient-to-b from-slate-50 to-blue-50/50 border border-slate-200/80 hover:border-blue-400 transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center mb-3 shadow-md shadow-sky-500/20 group-hover:scale-110 transition-transform">
                  <Video className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">Interview Prep</h4>
                <p className="text-xs text-slate-500 mt-1">Practice mock interviews with real-time STAR feedback.</p>
                <div className="mt-3 text-[11px] font-bold text-amber-600 flex items-center gap-1">
                  <span>Instant AI Feedback</span>
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Impact Numbers Section */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center border-t border-slate-200/80 pt-10 max-w-4xl mx-auto">
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-blue-600">100,000+</div>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">Students Guided</p>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-slate-900">95%</div>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">Placement Success Rate</p>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-blue-600">500+</div>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">Skill Roadmaps</p>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-extrabold text-slate-900">4.9 / 5</div>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">Student Satisfaction</p>
          </div>
        </div>

      </div>
    </section>
  );
};
