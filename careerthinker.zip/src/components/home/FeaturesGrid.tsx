import React from 'react';
import { Compass, FileText, Map, Video, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { PageTab } from '../../types';

interface FeaturesGridProps {
  setActiveTab: (tab: PageTab) => void;
  onSelectFeature?: (tab: 'guidance' | 'resume' | 'roadmaps' | 'interview') => void;
}

export const FeaturesGrid: React.FC<FeaturesGridProps> = ({ setActiveTab, onSelectFeature }) => {
  const features = [
    {
      id: 'guidance' as const,
      icon: Compass,
      title: 'AI Career Guidance',
      badge: 'Personalized AI Pathfinder',
      description: 'Discover the career paths that align with your unique personality, academic background, interests, and salary goals using Gemini AI.',
      highlights: [
        'Match percentage & job growth outlook',
        'Real-time salary range estimations',
        'Day-in-the-life work insights',
        'Actionable next steps checklist'
      ],
      color: 'from-blue-600 to-indigo-600',
      shadow: 'shadow-blue-500/20'
    },
    {
      id: 'resume' as const,
      icon: FileText,
      title: 'ATS Resume Builder & Auditor',
      badge: 'Smart Resume Optimizer',
      description: 'Create clean, ATS-compliant resumes or paste existing text to get instant scores, keyword analysis, and AI bullet rewrites.',
      highlights: [
        'Real-time ATS score calculation (0-100)',
        'AI bullet point optimizer with metric focus',
        'Industry-specific keyword recommendations',
        'Instant text export & copy options'
      ],
      color: 'from-indigo-600 to-blue-700',
      shadow: 'shadow-indigo-500/20'
    },
    {
      id: 'roadmaps' as const,
      icon: Map,
      title: 'Custom Skill Roadmaps',
      badge: 'Step-by-Step Learning Paths',
      description: 'Target your dream job with a structured week-by-week learning roadmap including key topics, projects, and top curated resources.',
      highlights: [
        'Milestone-based progress tracker',
        'Curated top tutorials & documentation',
        'Real-world capstone project ideas',
        'Customizable timeframes (6 - 16 Weeks)'
      ],
      color: 'from-blue-500 to-cyan-600',
      shadow: 'shadow-blue-400/20'
    },
    {
      id: 'interview' as const,
      icon: Video,
      title: 'AI Interview Simulator',
      badge: 'Interactive Mock Interviewer',
      description: 'Practice real technical and behavioral interview questions. Receive immediate feedback, score breakdowns, and model STAR answers.',
      highlights: [
        'Role-specific question bank',
        'STAR methodology answer evaluation',
        'Highlighting missing key points',
        'Ideal sample response generator'
      ],
      color: 'from-sky-600 to-blue-600',
      shadow: 'shadow-sky-500/20'
    }
  ];

  const handleFeatureClick = (featureId: 'guidance' | 'resume' | 'roadmaps' | 'interview') => {
    if (onSelectFeature) {
      onSelectFeature(featureId);
    }
    setActiveTab('features');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section id="features-preview" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold uppercase tracking-wider border border-blue-100">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Core AI Capabilities</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
            Everything You Need to Succeed in Your Career
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            CareerThinker equips students with intelligent tools designed to eliminate career guesswork and accelerate hiring outcomes.
          </p>
        </div>

        {/* Features 2x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                id={`feature-card-${item.id}`}
                onClick={() => handleFeatureClick(item.id)}
                className="bg-slate-50/70 rounded-3xl p-6 sm:p-8 border border-slate-200/80 hover:border-blue-300 hover:bg-white hover:shadow-xl hover:shadow-blue-900/5 transition-all duration-300 group cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-tr ${item.color} text-white flex items-center justify-center shadow-lg ${item.shadow} group-hover:scale-105 transition-transform`}>
                      <Icon className="w-7 h-7" />
                    </div>
                    <span className="text-xs font-semibold px-3 py-1 rounded-full bg-blue-100/80 text-blue-800 border border-blue-200">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors mb-3">
                    {item.title}
                  </h3>

                  <p className="text-slate-600 text-sm leading-relaxed mb-6">
                    {item.description}
                  </p>

                  <div className="space-y-2 border-t border-slate-200/60 pt-5 mb-6">
                    {item.highlights.map((h, i) => (
                      <div key={i} className="flex items-center gap-2.5 text-xs text-slate-700 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-2 text-sm font-bold text-blue-600 group-hover:text-blue-700">
                  <span>Try {item.title} Tool</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
