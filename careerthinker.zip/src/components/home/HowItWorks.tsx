import React from 'react';
import { Compass, Sparkles, Route, Trophy, ArrowRight } from 'lucide-react';
import { HOW_IT_WORKS_STEPS } from '../../data/mockData';
import { PageTab } from '../../types';

interface HowItWorksProps {
  setActiveTab: (tab: PageTab) => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ setActiveTab }) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass': return Compass;
      case 'Sparkles': return Sparkles;
      case 'Route': return Route;
      case 'Trophy': return Trophy;
      default: return Compass;
    }
  };

  return (
    <section id="how-it-works-section" className="py-20 bg-slate-900 text-white relative overflow-hidden">
      
      {/* Background glow accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="inline-block px-3.5 py-1 rounded-full bg-blue-900/60 text-blue-300 text-xs font-bold uppercase tracking-wider border border-blue-800">
            Streamlined Process
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
            How CareerThinker Works
          </h2>
          <p className="text-slate-400 text-base sm:text-lg leading-relaxed">
            From student uncertainty to landing your high-paying dream job in 4 simple AI-powered steps.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {HOW_IT_WORKS_STEPS.map((step, idx) => {
            const IconComponent = getIcon(step.icon);
            return (
              <div
                key={step.step}
                className="bg-slate-800/80 rounded-3xl p-6 border border-slate-700/80 hover:border-blue-500 transition-all duration-300 relative group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg shadow-md shadow-blue-500/20 group-hover:scale-110 transition-transform">
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <span className="text-3xl font-extrabold text-slate-600 group-hover:text-blue-400 transition-colors">
                      {step.step}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2">
                    {step.title}
                  </h3>

                  <p className="text-slate-400 text-sm leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {idx < HOW_IT_WORKS_STEPS.length - 1 && (
                  <div className="hidden lg:block absolute -right-4 top-1/2 -translate-y-1/2 z-20 text-slate-600">
                    <ArrowRight className="w-6 h-6" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom Call to Action */}
        <div className="mt-16 text-center">
          <button
            onClick={() => {
              setActiveTab('features');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-blue-600 text-white font-bold text-base hover:bg-blue-500 transition-colors shadow-lg shadow-blue-600/30"
          >
            <span>Start Your Career Journey Now</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </section>
  );
};
