import React from 'react';
import { Star, Quote, Award } from 'lucide-react';
import { TESTIMONIALS } from '../../data/mockData';

export const Testimonials: React.FC = () => {
  return (
    <section id="testimonials-section" className="py-20 bg-slate-50 border-y border-slate-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="inline-block px-3.5 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-wider border border-blue-200">
            Student Success Stories
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">
            Trusted by 100,000+ Career Thinkers
          </h2>
          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            See how students and recent graduates transformed their career outlooks and landed dream jobs at top companies.
          </p>
        </div>

        {/* Testimonials 2x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-md shadow-slate-200/40 hover:shadow-xl hover:border-blue-300 transition-all duration-300 relative flex flex-col justify-between"
            >
              <div>
                {/* Rating & Outcome Badge */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                    ))}
                  </div>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 font-bold text-xs border border-blue-100">
                    <Award className="w-3.5 h-3.5 text-blue-600" />
                    <span>{item.outcome}</span>
                  </span>
                </div>

                {/* Quote */}
                <p className="text-slate-700 text-base leading-relaxed italic mb-6">
                  "{item.quote}"
                </p>
              </div>

              {/* Student Profile */}
              <div className="flex items-center gap-4 border-t border-slate-100 pt-5">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-blue-200"
                />
                <div>
                  <h4 className="font-bold text-slate-900 text-base">{item.name}</h4>
                  <p className="text-xs font-semibold text-blue-600">{item.role}</p>
                  <p className="text-xs text-slate-400">{item.university}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
