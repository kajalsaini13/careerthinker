export type PageTab = 'home' | 'about' | 'features' | 'contact';

export type FeatureTab = 'guidance' | 'resume' | 'roadmaps' | 'interview';

export interface CareerRecommendation {
  title: string;
  matchPercentage: number;
  salaryRange: string;
  demand: string;
  description: string;
  keySkillsNeeded: string[];
  dayInLife: string;
  nextSteps: string[];
}

export interface BulletSuggestion {
  original: string;
  improved: string;
}

export interface ResumeReviewResult {
  score: number;
  summary: string;
  strengths: string[];
  improvements: string[];
  bulletSuggestions: BulletSuggestion[];
  atsKeywords: string[];
}

export interface RoadmapMilestone {
  phase: string;
  duration: string;
  topics: string[];
  projects: string[];
  recommendedResources: string[];
}

export interface SkillRoadmapResult {
  title: string;
  timeframe: string;
  milestones: RoadmapMilestone[];
}

export interface InterviewFeedbackResult {
  score: number;
  feedback: string;
  keyStrengths: string[];
  missingAspects: string[];
  sampleIdealResponse: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  university: string;
  image: string;
  quote: string;
  rating: number;
  outcome: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'general' | 'ai' | 'pricing' | 'resume';
}
