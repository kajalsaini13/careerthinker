import { Testimonial, FAQItem } from '../types';

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Ananya Sharma',
    role: 'Software Engineer @ Microsoft',
    university: 'IIT Bombay',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
    quote: 'The AI Career Guidance on CareerThinker helped me discover my true aptitude for Cloud Engineering. The interview prep simulator was eerily accurate for my Microsoft rounds!',
    rating: 5,
    outcome: 'Secured ₹32 LPA Offer'
  },
  {
    id: '2',
    name: 'Rohan Verma',
    role: 'Product Designer @ Flipkart',
    university: 'NIFT Delhi',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
    quote: 'CareerThinker’s Resume Builder optimized my project bullet points with real industry keywords. I went from 0 response rate to 6 interview calls in just 2 weeks!',
    rating: 5,
    outcome: '6 Top Tier Job Offers'
  },
  {
    id: '3',
    name: 'Priya Patel',
    role: 'Data Scientist @ Swiggy',
    university: 'BITS Pilani',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250',
    quote: 'The step-by-step Skill Roadmap gave me exact week-by-week targets and capstone projects. It took away all the confusion of self-learning data science.',
    rating: 5,
    outcome: 'Landed Dream Data Role'
  },
  {
    id: '4',
    name: 'Arjun Nair',
    role: 'Associate Consultant @ McKinsey',
    university: 'IIM Ahmedabad',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250',
    quote: 'The mock interview tool provided instant evaluation on my case study responses with actionable STAR framework feedback. Absolutely essential for students!',
    rating: 5,
    outcome: 'First-try Placement'
  }
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'general',
    question: 'How does CareerThinker help students choose the right career path?',
    answer: 'CareerThinker uses advanced AI algorithms to analyze your academic background, technical skills, personal interests, work style preferences, and market trends. It provides personalized career matches with detailed salary estimates, growth demand, and actionable next steps.'
  },
  {
    id: 'faq-2',
    category: 'ai',
    question: 'How accurate is the AI Resume Builder and ATS Checker?',
    answer: 'Our AI engine is trained on thousands of successfully accepted resumes across major tech, consulting, finance, and design companies. It checks keyword density, formatting, active action verbs, and quantifiable achievements to ensure maximum ATS pass rates.'
  },
  {
    id: 'faq-3',
    category: 'ai',
    question: 'Can I generate customized Skill Roadmaps for niche roles?',
    answer: 'Yes! Whether you are aiming for Full-Stack Engineering, AI Research, Cyber Security, UI/UX Design, or Product Management, you can generate custom week-by-week learning roadmaps tailored to your current experience level.'
  },
  {
    id: 'faq-4',
    category: 'pricing',
    question: 'Is CareerThinker free for students?',
    answer: 'Yes, CareerThinker offers a generous free tier for students that includes full access to Career Guidance, basic ATS Resume Review, sample Skill Roadmaps, and practice Mock Interviews.'
  },
  {
    id: 'faq-5',
    category: 'resume',
    question: 'How does the AI Mock Interviewer work?',
    answer: 'You select your target role and difficulty level. The AI asks real interview questions, listens to/reads your answers, and scores your performance using the STAR method, offering instant suggestions to improve your delivery.'
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    step: '01',
    title: 'Assess Your Profile',
    description: 'Share your background, interests, and career ambitions through our quick AI career assessment.',
    icon: 'Compass'
  },
  {
    step: '02',
    title: 'Get AI Recommendations',
    description: 'Receive personalized high-match career paths with real-time job market outlooks and salary insights.',
    icon: 'Sparkles'
  },
  {
    step: '03',
    title: 'Follow Custom Roadmaps',
    description: 'Master in-demand skills step-by-step with structured learning paths, projects, and top curated resources.',
    icon: 'Route'
  },
  {
    step: '04',
    title: 'Build Resume & Ace Interviews',
    description: 'Create ATS-friendly resumes and practice live AI mock interviews to land high-paying job offers.',
    icon: 'Trophy'
  }
];

export const TEAM_MEMBERS = [
  {
    name: 'Dr. Vivek Malhotra',
    role: 'Co-Founder & Chief AI Officer',
    bio: 'Ex-Google AI researcher, PhD in Machine Learning. Passionate about democratic access to career guidance.',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300'
  },
  {
    name: 'Meera Rao',
    role: 'Co-Founder & CEO',
    bio: 'Former Head of University Hiring at top Tech Unicorns. Guided 50,000+ graduates into tech careers.',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=300'
  },
  {
    name: 'Karan Singhania',
    role: 'Head of Product & Engineering',
    bio: 'Ex-Meta Senior Software Engineer. Built scalable learning products for millions of global learners.',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=300'
  }
];
