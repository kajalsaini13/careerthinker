import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Lazy-initialized Gemini client
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return null;
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // API 1: AI Career Guidance Pathfinder
  app.post("/api/ai/career-guidance", async (req, res) => {
    try {
      const { interests, skills, education, workStyle, goals } = req.body;
      const ai = getGeminiClient();

      if (!ai) {
        // High quality fallback data if API key isn't active
        return res.json({
          success: true,
          isFallback: true,
          recommendations: [
            {
              title: "AI Solutions Architect / Engineer",
              matchPercentage: 96,
              salaryRange: "$110,000 - $165,000 / yr",
              demand: "Extremely High (32% annual growth)",
              description: "Design and implement intelligent AI models and scalable web integrations to automate modern business workflows.",
              keySkillsNeeded: ["Python", "TypeScript", "LLM Fine-tuning", "Cloud Infrastructure", "System Architecture"],
              dayInLife: "Building AI agents, optimizing prompt pipelines, analyzing model benchmark performance, collaborating with product teams.",
              nextSteps: ["Master TypeScript & React", "Learn @google/genai SDK", "Build 2 full-stack portfolio projects"]
            },
            {
              title: "Product Manager (Tech & AI)",
              matchPercentage: 91,
              salaryRange: "$95,000 - $145,000 / yr",
              demand: "High Growth",
              description: "Lead product strategy, define feature roadmaps, and bridge customer needs with software engineering delivery.",
              keySkillsNeeded: ["Product Discovery", "Agile Roadmap Design", "Data Analytics", "UX/UI Sense", "Cross-functional Leadership"],
              dayInLife: "Conducting user interviews, reviewing metrics dashboards, sprint planning with developers, defining PRDs.",
              nextSteps: ["Obtain Certified Scrum Product Owner (CSPO)", "Analyze top SaaS products", "Lead a team project"]
            },
            {
              title: "Data Scientist & Analytics Lead",
              matchPercentage: 87,
              salaryRange: "$90,000 - $138,000 / yr",
              demand: "High",
              description: "Transform complex data streams into actionable business intelligence using statistical algorithms and predictive visualization.",
              keySkillsNeeded: ["SQL", "Python / R", "Machine Learning", "Tableau / PowerBI", "A/B Testing"],
              dayInLife: "Exploratory data analysis, writing SQL pipelines, building predictive statistical models, presenting insights to executives.",
              nextSteps: ["Complete SQL Advanced certification", "Practice Kaggle datasets", "Build a customer churn predictor"]
            }
          ]
        });
      }

      const prompt = `Act as an expert career counselor for students and graduates. Analyze the student's profile:
- Interests: ${interests || 'Technology, problem solving, innovation'}
- Current Skills: ${skills || 'Programming basics, communication'}
- Education: ${education || 'Undergraduate'}
- Work Style: ${workStyle || 'Collaborative, flexible'}
- Goals: ${goals || 'High growth career with great impact'}

Provide 3 highly tailored career recommendations in structured JSON format.
Each recommendation MUST contain:
- title (string)
- matchPercentage (number between 80 and 98)
- salaryRange (string e.g. "$80,000 - $120,000 / yr")
- demand (string e.g. "Extremely High")
- description (string)
- keySkillsNeeded (array of strings)
- dayInLife (string)
- nextSteps (array of strings)`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    matchPercentage: { type: Type.NUMBER },
                    salaryRange: { type: Type.STRING },
                    demand: { type: Type.STRING },
                    description: { type: Type.STRING },
                    keySkillsNeeded: { type: Type.ARRAY, items: { type: Type.STRING } },
                    dayInLife: { type: Type.STRING },
                    nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ["title", "matchPercentage", "salaryRange", "demand", "description", "keySkillsNeeded", "dayInLife", "nextSteps"]
                }
              }
            },
            required: ["recommendations"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json({ success: true, recommendations: parsed.recommendations || [] });
    } catch (err: any) {
      console.error("Error in guidance API:", err);
      return res.status(500).json({ error: "Failed to generate AI career guidance recommendations" });
    }
  });

  // API 2: AI Resume Reviewer & Bullet Optimizer
  app.post("/api/ai/resume-review", async (req, res) => {
    try {
      const { resumeText, targetRole } = req.body;
      const ai = getGeminiClient();

      if (!ai) {
        return res.json({
          success: true,
          isFallback: true,
          score: 84,
          summary: "Strong structural layout with clear chronological experience. High potential for tech roles.",
          strengths: [
            "Clear technical skill stack specified early in document",
            "Good usage of action verbs like 'Developed', 'Optimized', and 'Architected'",
            "Clean contact section and GitHub/LinkedIn link references"
          ],
          improvements: [
            "Quantify achievements with hard metrics (e.g., % performance boost, number of active users)",
            "Add ATS keywords specific to " + (targetRole || "target software industry"),
            "Condense summary section to 3 impactful lines focusing on unique value proposition"
          ],
          bulletSuggestions: [
            {
              original: "Responsible for building the website frontend and fixing bugs.",
              improved: "Architected modern responsive React/TypeScript frontend, reducing page load latency by 35% across 10k+ monthly active users."
            },
            {
              original: "Worked with team on database management.",
              improved: "Engineered scalable PostgreSQL schema migrations and optimized SQL query execution speeds by 40%."
            }
          ],
          atsKeywords: ["TypeScript", "REST APIs", "CI/CD Pipelines", "React 19", "Node.js", "Jest Unit Testing", "Agile Scrum"]
        });
      }

      const prompt = `Review the following resume content for a student targetting the role "${targetRole || 'Software Engineer'}":
---
${resumeText}
---

Provide a thorough, constructive feedback breakdown in structured JSON format with:
- score (number from 40 to 98)
- summary (string)
- strengths (array of strings)
- improvements (array of strings)
- bulletSuggestions (array of objects with 'original' and 'improved' strings)
- atsKeywords (array of strings for missing or recommended ATS keywords)`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              summary: { type: Type.STRING },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
              bulletSuggestions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    original: { type: Type.STRING },
                    improved: { type: Type.STRING }
                  },
                  required: ["original", "improved"]
                }
              },
              atsKeywords: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["score", "summary", "strengths", "improvements", "bulletSuggestions", "atsKeywords"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json({ success: true, ...parsed });
    } catch (err: any) {
      console.error("Error in resume review API:", err);
      return res.status(500).json({ error: "Failed to evaluate resume" });
    }
  });

  // API 3: AI Skill Roadmap Generator
  app.post("/api/ai/generate-roadmap", async (req, res) => {
    try {
      const { role, timeframe, level } = req.body;
      const ai = getGeminiClient();

      if (!ai) {
        return res.json({
          success: true,
          isFallback: true,
          title: `${role || "Full Stack Engineer"} Learning Path`,
          timeframe: timeframe || "12 Weeks",
          milestones: [
            {
              phase: "Phase 1: Core Fundamentals",
              duration: "Weeks 1 - 3",
              topics: ["HTML5 & Modern CSS Grid/Flexbox", "Core JavaScript ES6+", "Git Version Control & GitHub Flow"],
              projects: ["Personal Developer Portfolio", "Interactive Expense Tracker App"],
              recommendedResources: ["MDN Web Docs", "JavaScript.info", "CareerThinker Interactive Playground"]
            },
            {
              phase: "Phase 2: Frontend Engineering & Frameworks",
              duration: "Weeks 4 - 6",
              topics: ["React 19 Hooks & State Management", "TypeScript Fundamentals", "Tailwind CSS Styling Architecture"],
              projects: ["SaaS Analytics Dashboard", "E-commerce Product Catalog"],
              recommendedResources: ["React Docs", "TypeScript Deep Dive", "Tailwind CSS Labs"]
            },
            {
              phase: "Phase 3: Backend & Database Systems",
              duration: "Weeks 7 - 9",
              topics: ["Node.js & Express RESTful APIs", "SQL & Database Schema Modeling", "Authentication & Security"],
              projects: ["Full-Stack Task Manager API", "Auth System with OAuth2"],
              recommendedResources: ["Node.js Official Guide", "Postgres Tutorial", "OWASP Security Basics"]
            },
            {
              phase: "Phase 4: Cloud, Deployment & Career Prep",
              duration: "Weeks 10 - 12",
              topics: ["CI/CD Pipelines", "Cloud Deployment (Cloud Run / Vercel)", "System Design & Interview Prep"],
              projects: ["Production Capstone Application with Gemini AI"],
              recommendedResources: ["Google Cloud Tutorials", "CareerThinker Mock Interview Suite"]
            }
          ]
        });
      }

      const prompt = `Generate a detailed step-by-step career skill roadmap for becoming a "${role || 'Full Stack Engineer'}".
Experience Level: ${level || 'Beginner to Intermediate'}.
Desired Timeframe: ${timeframe || '12 Weeks'}.

Return structured JSON containing:
- title (string)
- timeframe (string)
- milestones (array of objects with:
    - phase (string e.g. "Phase 1: Fundamentals")
    - duration (string)
    - topics (array of strings)
    - projects (array of strings)
    - recommendedResources (array of strings)
)`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              timeframe: { type: Type.STRING },
              milestones: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    phase: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    topics: { type: Type.ARRAY, items: { type: Type.STRING } },
                    projects: { type: Type.ARRAY, items: { type: Type.STRING } },
                    recommendedResources: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ["phase", "duration", "topics", "projects", "recommendedResources"]
                }
              }
            },
            required: ["title", "timeframe", "milestones"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json({ success: true, ...parsed });
    } catch (err: any) {
      console.error("Error in roadmap API:", err);
      return res.status(500).json({ error: "Failed to generate roadmap" });
    }
  });

  // API 4: AI Mock Interview Evaluator
  app.post("/api/ai/interview-feedback", async (req, res) => {
    try {
      const { question, userResponse, targetRole } = req.body;
      const ai = getGeminiClient();

      if (!ai) {
        return res.json({
          success: true,
          isFallback: true,
          score: 88,
          feedback: "Great job! You clearly identified the core problem-solving methodology and structured your answer using the STAR method (Situation, Task, Action, Result).",
          keyStrengths: [
            "Direct and confident tone",
            "Included tangible metrics in the outcome description",
            "Good technical precision"
          ],
          missingAspects: [
            "Could briefly highlight team collaboration or conflict resolution steps",
            "Mention trade-offs evaluated during decision making"
          ],
          sampleIdealResponse: `In my last project, we faced a sudden 40% increase in API latency due to database locking. I conducted performance profiling using APM tools, identified unindexed foreign keys, and restructured query joins. This restored response times under 150ms and saved 20% server memory.`
        });
      }

      const prompt = `Role: Senior Interview Coach for ${targetRole || 'Software Engineering / Business'} candidate.
Question Asked: "${question}"
Candidate's Answer: "${userResponse}"

Evaluate the candidate's answer constructively in JSON format with:
- score (number 1-100)
- feedback (string summary)
- keyStrengths (array of strings)
- missingAspects (array of strings)
- sampleIdealResponse (string showing an exemplary high-impact answer)`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              feedback: { type: Type.STRING },
              keyStrengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              missingAspects: { type: Type.ARRAY, items: { type: Type.STRING } },
              sampleIdealResponse: { type: Type.STRING }
            },
            required: ["score", "feedback", "keyStrengths", "missingAspects", "sampleIdealResponse"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json({ success: true, ...parsed });
    } catch (err: any) {
      console.error("Error in interview feedback API:", err);
      return res.status(500).json({ error: "Failed to evaluate interview response" });
    }
  });

  // API 5: Contact Submission
  app.post("/api/contact", (req, res) => {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ error: "Please fill in all required fields" });
    }
    return res.json({
      success: true,
      message: `Thank you ${name}! Your message regarding "${subject || 'General Inquiry'}" has been received. Our team will contact you at ${email} within 24 hours.`
    });
  });

  // Vite middleware for dev or static serving for prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CareerThinker server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
